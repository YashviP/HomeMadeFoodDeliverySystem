# Gordo Rails App: Backend

This is the rails application for the
[*Gordo*](http://getgordo.com/) Food Delivery Service
by [Daniel Vogel](http://vogelito.com/).
